import { Header } from './header.js';
import { Login } from './login.js';
import { Footer } from './footer.js';

const app = document.getElementById('app');

app.innerHTML = `
    ${Header()}
    ${Login()}
    ${Footer()}
`;