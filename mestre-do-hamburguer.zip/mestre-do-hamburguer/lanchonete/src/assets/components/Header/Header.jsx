export function Header() {
    return `
        <header class="header">
            <div class="logo">
                <img src="logo.png" alt="Logo">
            </div>
        </header>
    `;
}