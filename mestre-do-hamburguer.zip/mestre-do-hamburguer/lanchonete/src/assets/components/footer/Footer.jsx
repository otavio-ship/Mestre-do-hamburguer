export function Footer() {
    return `
        <footer class="footer">
            <div class="logo-footer">
                <img src="logo.png" alt="Logo">
            </div>

            <div class="info-footer">
                <p>Contato: mestredohamburguer@vendas.com.br</p>
                <p>R: Salvador, nº233</p>
            </div>
        </footer>
    `;
}