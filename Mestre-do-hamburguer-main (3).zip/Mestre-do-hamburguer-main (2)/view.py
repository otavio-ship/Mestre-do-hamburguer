@app.route('/criar_usuario', methods=['POST'])
def criar_usuario():
    cur = con.cursor()

    try:
        nome = request.form.get('nome')
        email = request.form.get('email')
        senha = request.form.get('senha')

        if not nome or not email or not senha:
            return jsonify({'erro': 'Nome, email e senha são obrigatórios'}), 400

        # verifica se já existe
        cur.execute("SELECT id FROM USUARIO WHERE email = ?", (email,))
        if cur.fetchone():
            return jsonify({'erro': 'Email já cadastrado'}), 409

        senha_hash = criptografar(senha)

        cur.execute("""
            INSERT INTO USUARIO (nome, email, senha, tipo, data_criacao, ativo)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, 1)
        """, (nome, email, senha_hash, 'CLIENTE'))

        con.commit()

        return jsonify({'mensagem': 'Usuário criado com sucesso'}), 201

    except Exception as e:
        return jsonify({'erro': str(e)}), 500
    finally:
        cur.close()



@app.route('/login_usuario', methods=['POST'])
def login_usuario():
    cur = con.cursor()

    dados = request.get_json(silent=True)
    email = dados.get('email') if dados else request.form.get('email')
    senha = dados.get('senha') if dados else request.form.get('senha')

    if not email or not senha:
        return jsonify({'erro': 'Email e senha obrigatórios'}), 400

    try:
        cur.execute("SELECT id, senha, nome, tipo, ativo FROM USUARIO WHERE email = ?", (email,))
        user = cur.fetchone()

        if not user:
            return jsonify({'erro': 'Usuário não encontrado'}), 404

        id_user, senha_db, nome, tipo, ativo = user

        if not ativo:
            return jsonify({'erro': 'Usuário desativado'}), 403

        if not checar_senha(senha, senha_db):
            return jsonify({'erro': 'Senha incorreta'}), 401

        token = gerar_token(email)

        return jsonify({
            'mensagem': f'Bem-vindo {nome}',
            'token': token,
            'tipo': tipo
        })

    except Exception as e:
        return jsonify({'erro': str(e)}), 500
    finally:
        cur.close()



@app.route('/listar_usuarios', methods=['GET'])
def listar_usuarios():
    token = request.headers.get('Authorization')
    if not token:
        return jsonify({"mensagem": "Token necessário"}), 401

    cur = con.cursor()

    try:
        cur.execute('SELECT id, nome, email, tipo, ativo FROM USUARIO')
        usuarios = cur.fetchall()

        lista = []
        for u in usuarios:
            lista.append({
                "id": u[0],
                "nome": u[1],
                "email": u[2],
                "tipo": u[3],
                "ativo": bool(u[4])
            })

        return jsonify(lista)

    finally:
        cur.close()




@app.route('/Cardapio', methods=['GET'])
def cardapio():
    token = request.headers.get('Authorization')

    if not token:
        return jsonify({"mensagem": "Token necessário"}), 401

    cur = None

    try:
        cur = con.cursor()

        cur.execute('SELECT id, nome, descricao, preco, ativo FROM produtos')
        dados = cur.fetchall()

        resultado = []
        for d in dados:
            resultado.append({
                "id": d[0],
                "nome": d[1],
                "descricao": d[2],
                "preco": float(d[3]),
                "ativo": bool(d[4])
            })

        return jsonify(resultado)

    except Exception as e:
        return jsonify({"erro": str(e)}), 500

    finally:
        if cur:
            cur.close()